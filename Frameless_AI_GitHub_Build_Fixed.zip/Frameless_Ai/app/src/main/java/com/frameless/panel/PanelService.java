package com.frameless.panel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Frameless game panel: edge handle -> slide-in glass panel with stats, performance modes,
 * 12 quick tools, brightness + volume. Talks to the module through files/cmd + files/status.
 */
public class PanelService extends Service {
    static final int BG = 0xF0120A22, CARD = 0xFF1C1233, CARD2 = 0xFF251745, ACC = 0xFF8B5CF6, ACC2 = 0xFFC4B5FD,
            TXT = 0xFFFFFFFF, DIM = 0xFF9C8FBF, OK = 0xFF34D399, WARN = 0xFFF87171;

    WindowManager wm;
    AudioManager am;
    final Handler h = new Handler(Looper.getMainLooper());
    final Map<String, String> st = new HashMap<>();
    String pkg = "", gameName = "Game";
    boolean right = true, open = false;
    float dp;

    View handle, stripTop, stripBot;
    FrameLayout panelWin;
    LinearLayout panelBox;
    TextView hud, tvTitle, tvSub, tvMsg;
    TextView sFps, sCpu, sTemp, sBat, sRam, sProf;
    final TextView[] seg = new TextView[3];
    static final String[] SEG_KEY = {"balanced", "gaming", "boost"};
    static final String[] SEG_LBL = {"Everyday", "Arena", "Surge"};
    final Map<String, Tile> tiles = new HashMap<>();
    SeekBar sbBright, sbVol;
    boolean hudOn, antiOn, awakeOn, touchOn, brightDrag;
    long lastBright;

    // ---------- lifecycle ----------
    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent in, int flags, int id) {
        dp = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (in != null) {
            pkg = in.getStringExtra("pkg") == null ? pkg : in.getStringExtra("pkg");
            right = !"l".equals(in.getStringExtra("side"));
        }
        startFg();
        try { gameName = String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0))); }
        catch (Exception e) { gameName = pkg.isEmpty() ? "Game panel" : pkg; }
        removeAll();
        try { addHandle(); } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        h.removeCallbacks(tick); h.post(tick);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() { h.removeCallbacksAndMessages(null); removeAll(); super.onDestroy(); }

    void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("fp", "Game panel", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "fp").setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentTitle("Frameless game panel").setContentText("Swipe from the screen edge").build();
        startForeground(7, n);
    }

    final Runnable tick = new Runnable() {
        @Override public void run() { readStatus(); refresh(); h.postDelayed(this, 1000); }
    };

    // ---------- helpers ----------
    int px(float v) { return Math.round(v * dp); }

    GradientDrawable shape(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(px(radiusDp)); return g;
    }

    GradientDrawable grad(float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF8B5CF6, 0xFF6D28D9});
        g.setCornerRadius(px(radiusDp)); return g;
    }

    TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD); return t;
    }

    WindowManager.LayoutParams lp(int w, int hgt, int gravity, int flags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, hgt,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        p.gravity = gravity; return p;
    }

    void readStatus() {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(new File(getFilesDir(), "status"))))) {
            String l; while ((l = r.readLine()) != null) { int i = l.indexOf('='); if (i > 0) st.put(l.substring(0, i), l.substring(i + 1)); }
        } catch (Exception ignored) { }
    }

    String g(String k) { String v = st.get(k); return v == null ? "" : v; }

    void cmd(String line) {
        try (FileOutputStream o = new FileOutputStream(new File(getFilesDir(), "cmd"), true)) { o.write((line + "\n").getBytes()); }
        catch (Exception ignored) { }
    }

    void removeView(View v) { if (v != null) try { wm.removeView(v); } catch (Exception ignored) { } }

    void removeAll() {
        removeView(handle); removeView(panelWin); removeView(hud); removeView(stripTop); removeView(stripBot);
        handle = panelWin = null; hud = null; stripTop = stripBot = null; open = false;
    }

    // ---------- edge handle ----------
    void addHandle() {
        FrameLayout box = new FrameLayout(this);
        View pill = new View(this);
        GradientDrawable pg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFFC4B5FD, 0xFF8B5CF6});
        pg.setCornerRadius(px(3)); pill.setBackground(pg); pill.setAlpha(0.8f);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(px(5), px(72), (right ? Gravity.END : Gravity.START) | Gravity.CENTER_VERTICAL);
        pp.setMargins(px(2), 0, px(2), 0);
        box.addView(pill, pp);
        final float[] d = new float[2];
        box.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: d[0] = e.getRawX(); d[1] = 0; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = right ? d[0] - e.getRawX() : e.getRawX() - d[0];
                    if (dx > px(14)) { d[1] = 1; openPanel(); return true; }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (d[1] == 0) openPanel(); return true;
            }
            return false;
        });
        handle = box;
        wm.addView(box, lp(px(24), px(150), (right ? Gravity.END : Gravity.START) | Gravity.CENTER_VERTICAL,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL));
    }

    // ---------- panel ----------
    void openPanel() {
        if (open) return; open = true;
        boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        final FrameLayout win = new FrameLayout(this);
        // Compact floating card: keep the game visible and anchor the panel near the top edge.
        win.setBackground(shape(BG, 18));
        win.setClipToOutline(true);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setFillViewport(false);
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(px(10), px(10), px(10), px(12));
        sv.addView(col, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sv.setBackgroundColor(Color.TRANSPARENT);
        sv.setClickable(true);
        panelBox = col;

        buildHeader(col); buildStats(col); buildModes(col); buildTools(col); buildSliders(col);
        tvMsg = text("", 11, ACC2, false); tvMsg.setPadding(px(3), px(6), 0, 0); col.addView(tvMsg);

        int w = px(land ? 270 : 258);
        int hgt = px(land ? 300 : 410);
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        win.addView(sv, fp);
        sv.setTranslationX(right ? px(18) : -px(18));
        sv.animate().translationX(0).setDuration(180).start();
        win.setAlpha(0f); win.animate().alpha(1f).setDuration(150).start();

        panelWin = win;
        WindowManager.LayoutParams params = lp(w, hgt, (right ? Gravity.END : Gravity.START) | Gravity.TOP,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        params.x = px(6);
        params.y = px(42);
        wm.addView(win, params);
        refresh();
    }

    void closePanel() {
        if (!open) return; open = false;
        final View w = panelWin; panelWin = null;
        if (w != null) w.animate().alpha(0f).setDuration(150).withEndAction(() -> removeView(w)).start();
    }

    void buildHeader(LinearLayout col) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout names = new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        tvTitle = text(gameName, 15, TXT, true); tvTitle.setSingleLine(true);
        tvSub = text("Frameless Game Mode", 10, DIM, false);
        names.addView(tvTitle); names.addView(tvSub);
        row.addView(names, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView x = text("✕", 16, TXT, true); x.setGravity(Gravity.CENTER);
        x.setBackground(shape(CARD2, 18)); x.setOnClickListener(v -> closePanel());
        row.addView(x, new LinearLayout.LayoutParams(px(36), px(36)));
        col.addView(row);
    }

    TextView label(String s) {
        TextView t = text(s, 11, ACC2, true); t.setLetterSpacing(0.14f); t.setPadding(px(2), px(16), 0, px(8)); return t;
    }

    TextView stat(LinearLayout row, String name) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER);
        c.setBackground(shape(CARD, 14)); c.setPadding(0, px(9), 0, px(9));
        TextView v = text("--", 17, TXT, true); TextView n = text(name, 10, DIM, false);
        c.addView(v); c.addView(n);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(px(3), 0, px(3), 0); row.addView(c, p); return v;
    }

    void buildStats(LinearLayout col) {
        col.addView(label("LIVE"));
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        sFps = stat(r1, "FPS"); sCpu = stat(r1, "CPU"); sTemp = stat(r1, "TEMP");
        sBat = stat(r2, "BATTERY"); sRam = stat(r2, "RAM FREE"); sProf = stat(r2, "MODE");
        col.addView(r1);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = px(6); col.addView(r2, p);
    }

    void buildModes(LinearLayout col) {
        col.addView(label("PERFORMANCE"));
        LinearLayout row = new LinearLayout(this); row.setBackground(shape(CARD, 16)); row.setPadding(px(4), px(4), px(4), px(4));
        for (int i = 0; i < 3; i++) {
            final int k = i;
            TextView t = text(SEG_LBL[i], 13, DIM, true); t.setGravity(Gravity.CENTER); t.setPadding(0, px(10), 0, px(10));
            t.setOnClickListener(v -> { cmd("prof " + SEG_KEY[k]); st.put("prof", SEG_KEY[k]); refresh(); });
            seg[i] = t; row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        col.addView(row);
    }

    // ---------- tool tiles ----------
    class Tile {
        final LinearLayout box; final TextView icon, name; boolean on;
        Tile(String ic, String nm) {
            box = new LinearLayout(PanelService.this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER);
            icon = text(ic, 22, TXT, false); name = text(nm, 10.5f, TXT, true); name.setGravity(Gravity.CENTER); name.setSingleLine(true);
            box.addView(icon); box.addView(name); set(false);
        }
        void set(boolean o) {
            on = o; box.setBackground(o ? grad(16) : shape(CARD, 16)); name.setTextColor(o ? TXT : DIM); icon.setAlpha(o ? 1f : 0.85f);
        }
    }

    Tile tile(LinearLayout row, String key, String ic, String nm, final Runnable click) {
        final Tile t = new Tile(ic, nm);
        t.box.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, px(58), 1f); p.setMargins(px(3), px(3), px(3), px(3));
        row.addView(t.box, p); tiles.put(key, t); return t;
    }

    void toggleCmd(String key, String c) { Tile t = tiles.get(key); boolean n = !t.on; t.set(n); cmd(c + " " + (n ? 1 : 0)); }

    void buildTools(LinearLayout col) {
        col.addView(label("TOOLS")); tiles.clear();
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this), r3 = new LinearLayout(this), r4 = new LinearLayout(this);
        tile(r1, "dnd", "🌙", "No alerts", () -> toggleCmd("dnd", "dnd"));
        tile(r1, "mem", "🧹", "Clean RAM", () -> { cmd("mem"); flash("mem"); });
        tile(r1, "shot", "📸", "Screenshot", () -> { cmd("shot"); flash("shot"); closePanel(); });
        tile(r2, "rec", "⏺", "Record", () -> toggleCmd("rec", "rec"));
        tile(r2, "fps", "📊", "FPS overlay", () -> { hudOn = !hudOn; tiles.get("fps").set(hudOn); toggleHud(); });
        tile(r2, "ping", "📶", "Ping", () -> { cmd("ping"); flash("ping"); });
        tile(r3, "touch", "👆", "Touch boost", () -> { touchOn = !touchOn; tiles.get("touch").set(touchOn); cmd("touch " + (touchOn ? 1 : 0)); });
        tile(r3, "anti", "🛡", "Block edges", () -> { antiOn = !antiOn; tiles.get("anti").set(antiOn); toggleStrips(); });
        tile(r3, "awake", "💡", "Keep awake", () -> { awakeOn = !awakeOn; tiles.get("awake").set(awakeOn); keepAwake(); });
        tile(r4, "brl", "☀", "Lock bright", () -> toggleCmd("brl", "brlock"));
        tile(r4, "rot", "🔄", "Lock rotate", () -> toggleCmd("rot", "rot"));
        tile(r4, "byp", "🔋", "Pause charge", () -> toggleCmd("byp", "byp"));
        col.addView(r1); col.addView(r2); col.addView(r3); col.addView(r4);
        tiles.get("fps").set(hudOn); tiles.get("anti").set(antiOn); tiles.get("awake").set(awakeOn); tiles.get("touch").set(touchOn);
    }

    void flash(final String key) {
        final Tile t = tiles.get(key); if (t == null) return; t.set(true); h.postDelayed(() -> t.set(false), 900);
    }

    void buildSliders(LinearLayout col) {
        col.addView(label("BRIGHTNESS & VOLUME"));
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(shape(CARD, 16)); box.setPadding(px(14), px(12), px(14), px(12));
        sbBright = seek(box, "☀", 255);
        sbBright.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                if (u && System.currentTimeMillis() - lastBright > 250) { lastBright = System.currentTimeMillis(); cmd("bright " + Math.max(1, p)); }
            }
            public void onStartTrackingTouch(SeekBar s) { brightDrag = true; }
            public void onStopTrackingTouch(SeekBar s) { brightDrag = false; cmd("bright " + Math.max(1, s.getProgress())); }
        });
        sbVol = seek(box, "🔊", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        sbVol.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));
        sbVol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { if (u) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(box);
    }

    SeekBar seek(LinearLayout box, String ic, int max) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text(ic, 16, TXT, false), new LinearLayout.LayoutParams(px(26), -2));
        SeekBar sb = new SeekBar(this); sb.setMax(max);
        sb.getProgressDrawable().setTint(ACC); sb.getThumb().setTint(ACC2);
        row.addView(sb, new LinearLayout.LayoutParams(0, px(34), 1f));
        box.addView(row); return sb;
    }

    // ---------- floating pieces ----------
    void toggleHud() {
        if (hudOn && hud == null) {
            hud = text("FPS --", 12, TXT, true); hud.setPadding(px(10), px(5), px(10), px(5));
            hud.setBackground(shape(0xB3120A22, 10));
            WindowManager.LayoutParams p = lp(-2, -2, Gravity.TOP | Gravity.START,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            p.x = px(40); p.y = px(8);
            try { wm.addView(hud, p); } catch (Exception e) { hud = null; hudOn = false; }
        } else if (!hudOn) { removeView(hud); hud = null; }
    }

    void toggleStrips() {
        if (antiOn && stripTop == null) {
            int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            stripTop = new View(this); stripBot = new View(this);
            try {
                wm.addView(stripTop, lp(-1, px(22), Gravity.TOP, f));
                wm.addView(stripBot, lp(-1, px(22), Gravity.BOTTOM, f));
            } catch (Exception e) { antiOn = false; }
        } else if (!antiOn) { removeView(stripTop); removeView(stripBot); stripTop = stripBot = null; }
    }

    void keepAwake() {
        if (handle == null) return;
        WindowManager.LayoutParams p = (WindowManager.LayoutParams) handle.getLayoutParams();
        if (awakeOn) p.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON; else p.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        try { wm.updateViewLayout(handle, p); } catch (Exception ignored) { }
    }

    // ---------- live refresh ----------
    void refresh() {
        String fps = g("fps"), cpu = g("cpu"), temp = g("temp"), bat = g("bat");
        String fpsT = (fps.isEmpty() || fps.equals("0")) ? "--" : fps;
        if (hud != null) hud.setText("FPS " + fpsT + "  ·  CPU " + (cpu.isEmpty() ? "--" : cpu) + "%  ·  " + (temp.isEmpty() ? "--" : temp) + "°C");
        if (!open || panelWin == null) return;
        tvSub.setText("Frameless Game Mode  ·  " + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        sFps.setText(fpsT);
        sCpu.setText(cpu.isEmpty() ? "--" : cpu + "%");
        sTemp.setText(temp.isEmpty() ? "--" : temp + "°");
        int t = 0; try { t = Integer.parseInt(temp); } catch (Exception ignored) { }
        sTemp.setTextColor(t >= 44 ? WARN : TXT);
        sBat.setText(bat.isEmpty() ? "--" : bat + "%");
        String ram = g("ram"); sRam.setText(ram.isEmpty() ? "--" : String.format(Locale.US, "%.1fG", Integer.parseInt(ram) / 1024f));
        String pr = g("prof"); int sel = -1;
        for (int i = 0; i < 3; i++) {
            boolean on = SEG_KEY[i].equals(pr); if (on) sel = i;
            seg[i].setBackground(on ? grad(13) : null); seg[i].setTextColor(on ? TXT : DIM);
        }
        sProf.setText(sel >= 0 ? SEG_LBL[sel] : "--");
        setTile("dnd", "1".equals(g("dnd"))); setTile("rec", "1".equals(g("rec")));
        setTile("byp", "1".equals(g("byp"))); setTile("brl", "0".equals(g("brauto"))); setTile("rot", "0".equals(g("rot")));
        if (!brightDrag) try { sbBright.setProgress(Integer.parseInt(g("bright"))); } catch (Exception ignored) { }
        sbVol.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));
        tvMsg.setText(g("msg"));
    }

    void setTile(String k, boolean on) { Tile t = tiles.get(k); if (t != null && t.on != on) t.set(on); }
}
